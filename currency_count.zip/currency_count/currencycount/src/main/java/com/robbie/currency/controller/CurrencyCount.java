package com.robbie.currency.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@RestController
public class CurrencyCount {

    @Value(value="${filepath}")
    private String filePath;
    @GetMapping("/currencycount")
    public String currencyCount() throws Exception{
        StringBuffer sb = new StringBuffer();
        Map<String,Integer> map= new HashMap<>();

        File file = new File(filePath);
        BufferedReader br = new BufferedReader(new FileReader(file));
        String line;
        String[] split;
        while((line=br.readLine())!=null){
            split = line.split(" ");
            if(map.get(split[0])==null){
                map.put(split[0],Integer.valueOf(split[1]));
            }else{
                Integer original= map.get(split[0]);
                original=original+Integer.valueOf(split[1]);
                map.put(split[0],original);
            }

        }
        Set<Map.Entry<String, Integer>> entries = map.entrySet();
        int i=0;
        for(Map.Entry<String,Integer> entry:entries){
            sb.append(entry.getKey());
            sb.append(" ");
            sb.append(entry.getValue());
            if(i<(entries.size()-1)){
                sb.append("\r\n");
            }
        }



        return sb.toString();

    }
}
